export const myFavoritiesMovies = [
  "bienvenidos al ayer",
  "shazam",
  "american pie",
  "kingsman",
  "el conjuro",
  "annabelle",
  "megadol"
]